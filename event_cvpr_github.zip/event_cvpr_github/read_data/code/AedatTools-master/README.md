# AedatTools
Tools for manipulating .aedat files (timestamped address-event data from neuromorphic hardware), in Matlab and Python.

I only forked this to keep the commits associated to my account! Please refer to the original https://github.com/inivation/AedatTools.
