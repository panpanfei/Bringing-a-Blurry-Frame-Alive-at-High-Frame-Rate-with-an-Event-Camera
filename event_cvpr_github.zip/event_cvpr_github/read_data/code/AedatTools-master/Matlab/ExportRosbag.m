function ExportRosbag(aedat)

%{
This is a placeholder. The function has been written in the python library.
It exports to Rosbag format following RPG-DVS-ROS conventions
%}


